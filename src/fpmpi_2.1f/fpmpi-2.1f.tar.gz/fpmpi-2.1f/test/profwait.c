/*
 * This test checks that wait, waitsome, waitany, waitall and their
 * test equivalents work with the fpmpi library.  These are special 
 * routines because fpmpi has an option for computing wait time separately
 * from the time spent receiving a message 
 */

#include "mpi.h"
#include <stdio.h>
#include <stdlib.h>

void delay( double );
void setBuf( int [], int, int );
int checkBuf( const int [], int, int, MPI_Status * );

void delay( double dt )
{
    double t1 = MPI_Wtime();
    while (MPI_Wtime() - t1 < dt) ;
}

void setBuf( int s[], int n, int val )
{
    int i;
    for (i=0; i<n; i++) {
	s[i] = val + i;
    }
}
int checkBuf( const int r[], int n, int val, MPI_Status *s )
{
    int i, count, errs = 0;

    for (i=0; i<n; i++) {
	if (r[i] != val + i) {
	    fprintf( stderr, "r[%d] = %d, expected %d\n", i, r[i], val + i );
	    errs += 1;
	}
    }
    MPI_Get_count( s, MPI_INT, &count );
    if (count != n) {
	fprintf( stderr, "expected %d ints but got %d (val=%d)\n", n, count, val );
	errs++;
    }

    return errs;
}

int main( int argc, char *argv[])
{
    int sbuf[10], rbuf[10];
    int wrank, wsize;
    int flag, idx, indices[2], outcount;
    int errs = 0, toterrs;
    MPI_Request r[2];
    MPI_Status  s[2];

    MPI_Init( &argc, &argv );

    MPI_Comm_rank( MPI_COMM_WORLD, &wrank );
    MPI_Comm_size( MPI_COMM_WORLD, &wsize );

    if (wrank == 0) {
	/* A succession of send/receives with process 1, using nonblocking
	   operations */

	/* 1. Send 1-9, recv 11-19 */
	setBuf( sbuf, 10, 1 );
	MPI_Isend( sbuf, 10, MPI_INT, 1, 1, MPI_COMM_WORLD, &r[0] );
	MPI_Irecv( rbuf, 10, MPI_INT, 1, 1, MPI_COMM_WORLD, &r[1] );
	MPI_Wait( &r[0], &s[0] );
	do {
	    MPI_Test( &r[1], &flag, &s[1] );
	} while( ! flag );
	errs += checkBuf( rbuf, 10, 11, &s[1] );

	/* 2. send 21-29, recv 31-39 */
	setBuf( sbuf, 10, 21 );
	MPI_Issend( sbuf, 10, MPI_INT, 1, 2, MPI_COMM_WORLD, &r[0] );
	MPI_Irecv( rbuf, 10, MPI_INT, 1, 2, MPI_COMM_WORLD, &r[1] );
	MPI_Waitsome( 2, r, &outcount, indices, s );
	if (outcount == 1) {
	    if (indices[0] == 1) {
		s[1] = s[0];
		MPI_Wait( &r[0], &s[0] );
	    }
	    else {
		MPI_Wait( &r[1], &s[1] );
	    }
	}
	errs += checkBuf( rbuf, 10, 31, &s[1] );

	/* 3. send 41-49, recv 51-59 */
	setBuf( sbuf, 10, 41 );
	MPI_Isend( sbuf, 10, MPI_INT, 1, 3, MPI_COMM_WORLD, &r[0] );
	MPI_Irecv( rbuf, 10, MPI_INT, 1, 3, MPI_COMM_WORLD, &r[1] );
	MPI_Waitany( 2, r, &idx, &s[0] );
	if (idx != 0) s[1] = s[0];
	MPI_Wait( &r[1-idx], &s[1-idx] );
	errs += checkBuf( rbuf, 10, 51, &s[1] );

	/* 4. send 61-69, recv 71-79 */
	setBuf( sbuf, 10, 61 );
	MPI_Isend( sbuf, 10, MPI_INT, 1, 4, MPI_COMM_WORLD, &r[0] );
	MPI_Irecv( rbuf, 10, MPI_INT, 1, 4, MPI_COMM_WORLD, &r[1] );
	MPI_Waitall( 2, r, s );
	errs += checkBuf( rbuf, 10, 71, &s[1] );

	/* 5. send 81-89, recv 91-99 */
	setBuf( sbuf, 10, 81 );
	MPI_Isend( sbuf, 10, MPI_INT, 1, 4, MPI_COMM_WORLD, &r[0] );
	MPI_Irecv( rbuf, 10, MPI_INT, 1, 4, MPI_COMM_WORLD, &r[1] );
	MPI_Waitall( 1, &r[1], &s[1] );
	MPI_Waitall( 1, &r[0], &s[0] );
	errs += checkBuf( rbuf, 10, 91, &s[1] );
	   
    }
    else if (wrank == 1) {
	/* A succession of blocking send/receives with process 1, with 
	   an occasional delay */
	/* 1. Recv 1-9, send 11-19 */
	setBuf( sbuf, 10, 11 );
	delay( 0.01 );
	MPI_Sendrecv( sbuf, 10, MPI_INT, 0, 1, 
		      rbuf, 10, MPI_INT, 0, 1, MPI_COMM_WORLD, &s[0] );
	errs += checkBuf( rbuf, 10, 1, &s[0] );

	/* 2. Recv 21-39, send 31-39 */
	delay( 0.02 );
	setBuf( sbuf, 10, 31 );
	MPI_Sendrecv( sbuf, 10, MPI_INT, 0, 2, 
		      rbuf, 10, MPI_INT, 0, 2, MPI_COMM_WORLD, &s[0] );
	errs += checkBuf( rbuf, 10, 21, &s[0] );

	/* 3. Recv 41-49, send 51-59 */
	delay( 0.03 );
	setBuf( sbuf, 10, 51 );
	MPI_Sendrecv( sbuf, 10, MPI_INT, 0, 3, 
		      rbuf, 10, MPI_INT, 0, 3, MPI_COMM_WORLD, &s[0] );
	errs += checkBuf( rbuf, 10, 41, &s[0] );

	/* 4. Recv 61-69, send 71-79 */
	delay( 0.04 );
	setBuf( sbuf, 10, 71 );
	MPI_Sendrecv( sbuf, 10, MPI_INT, 0, 4, 
		      rbuf, 10, MPI_INT, 0, 4, MPI_COMM_WORLD, &s[0] );
	errs += checkBuf( rbuf, 10, 61, &s[0] );

	/* 4. Recv 81-89, send 91-99 */
	delay( 0.04 );
	setBuf( sbuf, 10, 91 );
	MPI_Sendrecv( sbuf, 10, MPI_INT, 0, 4, 
		      rbuf, 10, MPI_INT, 0, 4, MPI_COMM_WORLD, &s[0] );
	errs += checkBuf( rbuf, 10, 81, &s[0] );
    }

    MPI_Allreduce( &errs, &toterrs, 1, MPI_INT, MPI_SUM, MPI_COMM_WORLD );
    if (wrank == 0) {
	if (toterrs > 0) {
	    printf( " Found %d errors\n", toterrs );
	}
	else {
	    printf( " No errors\n" );
	}
    }
    MPI_Finalize();

    return 0;
}
