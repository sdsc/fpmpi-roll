#include <mpi.h>
#include <stdio.h>
#define TEST_SIZE 2000
void clear_test_data(float *, int);
void init_test_data(float *,int);
void verify_test_data(float *,int,int,const char []);
void msg_check(float *,int,int,int,MPI_Status,int,const char []);
void rq_check(MPI_Request [],int, const char []);

int main(int argc,char *argv[]) {
  int prev, next, count, tag, index, i, outcount;
  int indices[2], rank, size;
  MPI_Status  status, statuses[2];
  MPI_Request requests[2];
  MPI_Comm    dupcom;
  int         flag;
  float       send_buff[TEST_SIZE], recv_buff[TEST_SIZE];

  MPI_Init(&argc,&argv);

  MPI_Comm_rank(MPI_COMM_WORLD, &rank);
  MPI_Comm_size(MPI_COMM_WORLD, &size);
  if (size != 2) {
    printf("All_pair test requires exactly 2 processes.\n");
    MPI_Abort(MPI_COMM_WORLD,1);
  }
  MPI_Comm_dup(MPI_COMM_WORLD, &dupcom);

  next = rank + 1;
  if (next >= size) next = 0;
  prev = rank -1;
  if (prev < 0) prev = size -1;

/*   Normal Sends */
  if (rank == 0) printf("    Send\n");
  tag = 1123;
  count = TEST_SIZE / 5;

  clear_test_data(recv_buff,TEST_SIZE);

  if (rank == 0) {
    init_test_data(send_buff,TEST_SIZE);
    MPI_Send(send_buff, count, MPI_REAL, next, tag, MPI_COMM_WORLD);
    MPI_Recv(recv_buff, TEST_SIZE, MPI_REAL, MPI_ANY_SOURCE,
             MPI_ANY_TAG, MPI_COMM_WORLD, &status);
    msg_check(recv_buff, prev, tag, count, status, TEST_SIZE, "send and recv");
  } else {
    MPI_Recv(recv_buff, TEST_SIZE, MPI_REAL, MPI_ANY_SOURCE,
             MPI_ANY_TAG, MPI_COMM_WORLD, &status);
    msg_check(recv_buff, prev, tag, count, status, TEST_SIZE, "send and recv");
    MPI_Send(recv_buff, count, MPI_REAL, next, tag, MPI_COMM_WORLD);
  }

/*   Ready sends. Note that we must insure that the receive is posted */
/*      before the rsend; this requires using Irecv. */

  if (rank == 0) {
    init_test_data(send_buff, TEST_SIZE);
    MPI_Recv(MPI_BOTTOM, 0, MPI_INTEGER, next, tag, MPI_COMM_WORLD, &status);
    MPI_Rsend(send_buff, count, MPI_REAL, next, tag, MPI_COMM_WORLD);
    MPI_Probe(MPI_ANY_SOURCE, tag, MPI_COMM_WORLD, &status);
    if (status.MPI_SOURCE != prev) {
      printf("Incorrect source, expected %d, got %d\n",prev,status.MPI_SOURCE);
    }
    if (status.MPI_TAG != tag) {
      printf("Incorrect tag, expected %d, got %d\n",tag,status.MPI_TAG);
    }
    MPI_Get_count(&status,MPI_REAL, &i);
    if (i != count) {
      printf("Incorrect count, expected %d, got %d\n",count, i);
    }
    MPI_Recv(recv_buff, TEST_SIZE, MPI_REAL, MPI_ANY_SOURCE, MPI_ANY_TAG,
             MPI_COMM_WORLD, &status);
    msg_check(recv_buff, prev, tag, count, status, TEST_SIZE, "rsend and recv");
  } else {
    MPI_Irecv(recv_buff, TEST_SIZE, MPI_REAL, MPI_ANY_SOURCE, MPI_ANY_TAG,
              MPI_COMM_WORLD, &requests[0]);
    MPI_Send(MPI_BOTTOM, 0, MPI_INTEGER, next, tag, MPI_COMM_WORLD);
    MPI_Wait(&requests[0], &status);
    msg_check(recv_buff, prev, tag, count, status, TEST_SIZE, "rsend and recv");
    MPI_Send(recv_buff, count, MPI_REAL, next, tag, MPI_COMM_WORLD);
  }

/*   Synchronous sends */

  if (rank == 0) printf("    Ssend\n");
  tag = 1789;
  count = TEST_SIZE / 3;

  clear_test_data(recv_buff, TEST_SIZE);

  if (rank == 0) {
    init_test_data(send_buff, TEST_SIZE);
    MPI_Iprobe(MPI_ANY_SOURCE, tag, MPI_COMM_WORLD, &flag, &status);
    if (flag) {
      printf("Iprobe succeeded! source %d, tag %d\n",
             status.MPI_SOURCE, status.MPI_TAG);
    }
    MPI_Ssend(send_buff, count, MPI_REAL, next, tag, MPI_COMM_WORLD);
    while (!flag) {
      MPI_Iprobe(MPI_ANY_SOURCE, tag, MPI_COMM_WORLD, &flag, &status);
    }
    if (status.MPI_SOURCE != prev) {
      printf("Incorrect source, expected %d, got %d\n", prev, status.MPI_SOURCE);
    }
    if (status.MPI_TAG != tag) {
      printf("Incorrect tag, expected %d, got %d\n", tag, status.MPI_TAG);
    }
    MPI_Get_count(&status, MPI_REAL, &i);
    if (i != count) {
      printf("Incorrect count, expected %d, got %d\n", count, i);
    }
    MPI_Recv(recv_buff, TEST_SIZE, MPI_REAL, MPI_ANY_SOURCE, MPI_ANY_TAG,
             MPI_COMM_WORLD, &status);
    msg_check(recv_buff, prev, tag, count, status, TEST_SIZE, "ssend and recv");
  } else { 
    MPI_Recv(recv_buff, TEST_SIZE, MPI_REAL, MPI_ANY_SOURCE, MPI_ANY_TAG,
             MPI_COMM_WORLD, &status);
    msg_check(recv_buff, prev, tag, count, status, TEST_SIZE, "ssend and recv");
    MPI_Ssend(recv_buff, count, MPI_REAL, next, tag, MPI_COMM_WORLD);
  }

/*   Nonblocking normal sends */

  if (rank == 0) printf("    Isend\n");
  tag = 2123;
  count = TEST_SIZE / 5;

  clear_test_data(recv_buff, TEST_SIZE);

  if (rank == 0) {
    MPI_Irecv(recv_buff, TEST_SIZE, MPI_REAL, MPI_ANY_SOURCE,
              MPI_ANY_TAG, MPI_COMM_WORLD, &requests[0]);
    init_test_data(send_buff, TEST_SIZE);
    MPI_Isend(send_buff, count, MPI_REAL, next, tag, MPI_COMM_WORLD, &requests[1]);
    MPI_Waitall(2, requests, statuses);
    rq_check(requests, 2, "isend and irecv");
    msg_check(recv_buff, prev, tag, count, statuses[0], TEST_SIZE, "isend and irecv");
  } else {
    MPI_Recv(recv_buff, TEST_SIZE, MPI_REAL, MPI_ANY_SOURCE,
             MPI_ANY_TAG, MPI_COMM_WORLD, &status);
    msg_check(recv_buff, prev, tag, count, status, TEST_SIZE, "isend and irecv");
    MPI_Isend(recv_buff, count, MPI_REAL, next, tag, MPI_COMM_WORLD, &requests[0]);
    MPI_Wait(&requests[0], &status);
    rq_check(requests,1,"isend and irecv");
  }

/*   Nonblocking ready sends */

  if (rank == 0) printf("    Irsend\n");
  tag = 2456;
  count = TEST_SIZE / 3;

  clear_test_data(recv_buff, TEST_SIZE);

/*   This test needs work for comm_size > 2 */

  if (rank == 0) {
    MPI_Irecv(recv_buff, TEST_SIZE, MPI_REAL, MPI_ANY_SOURCE,
              MPI_ANY_TAG, MPI_COMM_WORLD, &requests[0]);
    init_test_data(send_buff, TEST_SIZE);
    MPI_Sendrecv(MPI_BOTTOM, 0, MPI_INTEGER, next, 0,
                 MPI_BOTTOM, 0, MPI_INTEGER, next, 0,
                 dupcom, &status);
    MPI_Irsend(send_buff, count, MPI_REAL, next, tag, MPI_COMM_WORLD, &requests[1]);
    index = -1;
    while (index != 0) {
      MPI_Waitany(2, requests, &index, &status);
    }
    rq_check(requests, 1, "irsend and irecv");
    msg_check(recv_buff, prev, tag, count, status,TEST_SIZE,"irsend and irecv");
  } else {
    MPI_Irecv(recv_buff, TEST_SIZE, MPI_REAL, MPI_ANY_SOURCE,
              MPI_ANY_TAG, MPI_COMM_WORLD, &requests[0]);
    MPI_Sendrecv(MPI_BOTTOM, 0, MPI_INTEGER, next, 0,
                 MPI_BOTTOM, 0, MPI_INTEGER, next, 0,
                 dupcom, &status);
    flag = 0;
    while (!flag) {
      MPI_Test(&requests[0], &flag, &status);
    }
    rq_check(requests, 1, "irsend and irecv (test)");
    msg_check(recv_buff, prev, tag, count, status, TEST_SIZE, "irsend and irecv");
    MPI_Irsend(recv_buff, count, MPI_REAL, next, tag, MPI_COMM_WORLD, &requests[0]);
    MPI_Waitall(1,requests, statuses);
    rq_check(requests, 1, "irsend and irecv");
  }

/*    Nonblocking synchronous sends */

  if (rank == 0) printf("    Issend\n");
  tag = 2789;
  count = TEST_SIZE / 3;

  clear_test_data(recv_buff, TEST_SIZE);

  if (rank == 0) {
    MPI_Irecv(recv_buff, TEST_SIZE, MPI_REAL, MPI_ANY_SOURCE,
              MPI_ANY_TAG, MPI_COMM_WORLD, &requests[0]);
    init_test_data(send_buff, TEST_SIZE);
    MPI_Issend(send_buff, count, MPI_REAL, next, tag,
               MPI_COMM_WORLD, &requests[1]);
    flag = 0;
    while (!flag) {
      MPI_Testall(2, requests, &flag, statuses);
    }
    rq_check(requests, 2, "issend and irecv (testall)");
    msg_check(recv_buff, prev, tag, count, statuses[0], TEST_SIZE, "issend and recv (testall)");
  } else {
    MPI_Recv(recv_buff, TEST_SIZE, MPI_REAL, MPI_ANY_SOURCE,
             MPI_ANY_TAG, MPI_COMM_WORLD, &status);
    msg_check(recv_buff, prev, tag, count, status, TEST_SIZE, "issend and recv");
    MPI_Issend(recv_buff, count, MPI_REAL, next, tag,
               MPI_COMM_WORLD, &requests[0]);
    flag = 0;
    while (!flag) {
      MPI_Testany(1, &requests[0], &index, &flag, &statuses[0]);
    }
    rq_check(requests, 1, "issend and recv (testany)");
  }

/*    Persistent normal sends */

  if (rank == 0) printf("    Send_init\n");
  tag = 3123;
  count = TEST_SIZE / 5;

  clear_test_data(recv_buff, TEST_SIZE);

  MPI_Send_init(send_buff, count, MPI_REAL, next, tag,
                MPI_COMM_WORLD, &requests[0]);
  MPI_Recv_init(recv_buff, TEST_SIZE, MPI_REAL, MPI_ANY_SOURCE,
                MPI_ANY_TAG, MPI_COMM_WORLD, &requests[1]);
  if (rank == 0) {
    init_test_data(send_buff, TEST_SIZE);
    MPI_Startall(2, requests);
    MPI_Waitall(2, requests, statuses);
    msg_check(recv_buff, prev, tag, count, statuses[1], TEST_SIZE, "persistend send/recv");
  } else {
    MPI_Start(&requests[1]);
    MPI_Wait(&requests[1], &status);
    msg_check(recv_buff, prev, tag, count, status, TEST_SIZE, "persistent send/recv");
    for (i=0;i<count;i++) send_buff[i] = recv_buff[i];
    MPI_Start(&requests[0]);
    MPI_Wait(&requests[0],&status);
  }
  MPI_Request_free(&requests[0]);
  MPI_Request_free(&requests[1]);

/*   Persistent ready sends */

  if (rank == 0) printf("    Rsend_init\n");
  tag = 3456;
  count = TEST_SIZE / 3;

  clear_test_data(recv_buff, TEST_SIZE);

  MPI_Rsend_init(send_buff, count, MPI_REAL, next, tag,
                 MPI_COMM_WORLD, &requests[0]);
  MPI_Recv_init(recv_buff, TEST_SIZE, MPI_REAL, MPI_ANY_SOURCE,
                MPI_ANY_TAG, MPI_COMM_WORLD, &requests[1]);
  if (rank == 0) {
    init_test_data(send_buff, TEST_SIZE);
    MPI_Startall(2, requests);
    index = -1;
    while (index != 2) {
      MPI_Waitsome(2, requests, &outcount, indices, statuses);
      for (i=0;i<outcount; i++) {
        if (indices[i] == 1) {
          msg_check(recv_buff, prev, tag, count, statuses[i],
                    TEST_SIZE, "waitsome");
          index = 2;
        }
      }
    }
  } else {
    MPI_Start(&requests[1]);
    flag = 0;
    while (!flag)
      MPI_Test(&requests[1], &flag, &status);
    msg_check(recv_buff, prev, tag, count, status, TEST_SIZE, "test");
    for (i=0;i<count;i++)
      send_buff[i] = recv_buff[i];
    MPI_Start(&requests[0]);
    MPI_Wait(&requests[0],&status);
  }
  MPI_Request_free(&requests[0]);
  MPI_Request_free(&requests[1]);

/*    Persistent synchronous sends */

  if (rank == 0) printf("    Ssend_init\n");
  tag = 3789;
  count = TEST_SIZE /3;

  clear_test_data(recv_buff, TEST_SIZE);
  MPI_Ssend_init(send_buff, count, MPI_REAL, next, tag,
                 MPI_COMM_WORLD, &requests[1]);
  MPI_Recv_init(recv_buff, TEST_SIZE, MPI_REAL, MPI_ANY_SOURCE,
                MPI_ANY_TAG, MPI_COMM_WORLD, &requests[0]);
  if (rank == 0) {
    init_test_data(send_buff, TEST_SIZE);
    MPI_Startall(2,requests);

    index = -1;
    while (index != 1) {
      MPI_Testsome(2, requests, &outcount, indices, statuses);
      for (i=0;i<outcount;i++) {
        if (indices[i] == 0) {
          msg_check(recv_buff, prev, tag, count, statuses[i],
                    TEST_SIZE, "testsome");
          index = 1;
        }
      }
    }
  } else {
    MPI_Start(&requests[0]);
    flag = 0;
    while (!flag)
      MPI_Testany(1, &requests[0], &index, &flag, &statuses[0]);
    msg_check(recv_buff, prev, tag, count, statuses[0],
              TEST_SIZE, "testany");
    for (i=0;i<count;i++) send_buff[i] = recv_buff[i];
    MPI_Start(&requests[1]);
    MPI_Wait(&requests[1],&status);
  }
  MPI_Request_free(&requests[0]);
  MPI_Request_free(&requests[1]);

/*    Send/receive */

  if (rank == 0) printf("    Sendrecv\n");
  tag = 4123;
  count = TEST_SIZE / 5;

  clear_test_data(recv_buff, TEST_SIZE);

  if (rank == 0) {
    init_test_data(send_buff, TEST_SIZE);
    MPI_Sendrecv(send_buff, count, MPI_REAL, next, tag,
                 recv_buff, count, MPI_REAL, prev, tag,
                 MPI_COMM_WORLD, &status);
    msg_check(recv_buff, prev, tag, count, status, TEST_SIZE, "sendrecv");
  } else {
    MPI_Recv(recv_buff, TEST_SIZE, MPI_REAL, MPI_ANY_SOURCE,
             MPI_ANY_TAG, MPI_COMM_WORLD, &status);
    msg_check(recv_buff, prev, tag, count, status, TEST_SIZE, "recv/send");
    MPI_Send(recv_buff, count, MPI_REAL, next, tag, MPI_COMM_WORLD);
  }

/*    Send/receive replace */

  if (rank == 0) printf("    Sendrecv_replace\n");
  tag = 4456;
  count = TEST_SIZE / 3;

  if (rank == 0) {
    init_test_data(recv_buff, TEST_SIZE);
    for (i=count; i<TEST_SIZE; i++) recv_buff[i]=0.0;
    MPI_Sendrecv_replace(recv_buff, count, MPI_REAL, next, tag,
                         prev, tag, MPI_COMM_WORLD, &status);
    msg_check(recv_buff, prev, tag, count, status,
              TEST_SIZE, "sendrecvreplace");
  } else {
    clear_test_data(recv_buff, TEST_SIZE);
    MPI_Recv(recv_buff, TEST_SIZE, MPI_REAL, MPI_ANY_SOURCE,
             MPI_ANY_TAG, MPI_COMM_WORLD, &status);
    msg_check(recv_buff, prev, tag, count, status,
              TEST_SIZE, "recv/send for replace");
    MPI_Send(recv_buff, count, MPI_REAL, next, tag, MPI_COMM_WORLD);
  }
  
  MPI_Comm_free(&dupcom);    
  MPI_Finalize();
  return(0);
}

void clear_test_data(float *buff, int n) {
  int i;
  for (i=0;i<n;i++) buff[i] = 0.;
  return;
}

void init_test_data(float *buff, int n) {
  int i;
  for (i=0;i<n;i++) buff[i] = (float)i;
  return;
}

void verify_test_data(float *buff, int count, int n, const char name[]) {
  int i;
  for (i=0;i<count;i++) {
    if (buff[i] != (float)i) {
      printf("Invalid data %6.1g at %4i of %4i in %s.\n",buff[i],i+1,count,name);
      MPI_Abort(MPI_COMM_WORLD, 108);
    }
  }
  for (i=count;i<n;i++) {
    if (buff[i] != 0) {
      printf("Invalid data %6.1g at %4i of %4i in %s.\n",buff[i],i+1,count,name);
      MPI_Abort(MPI_COMM_WORLD, 108);
    }
  }
  return;
}

void msg_check(float *recv_buff, int source, int tag, int count, MPI_Status status, int n, const char name[]) {
  int recv_src, recv_tag, recv_count, rank;;
  
  recv_src = status.MPI_SOURCE;
  recv_tag = status.MPI_TAG;

  MPI_Comm_rank(MPI_COMM_WORLD, &rank);
  MPI_Get_count(&status, MPI_REAL, &recv_count);
 
  if (recv_src != source) {
    printf("[%d] Unexpected source: %d in %s\n",rank,recv_src,name);
    MPI_Abort(MPI_COMM_WORLD,101);
  }

  if (recv_tag != tag) {
    printf("[%d] Unexpected tag: %d in %s\n",rank,recv_tag,name);
    MPI_Abort(MPI_COMM_WORLD,102);
  }

  if (recv_count != count) {
    printf("[%d] Unexpected count: %d in %s\n",rank,recv_count,name);
    MPI_Abort(MPI_COMM_WORLD,103);
  }

  verify_test_data(recv_buff,count,n,name);
  return;
}

void rq_check(MPI_Request requests[],int n, const char msg[]) {
  int i;

  for (i=0;i<n;i++) {
    if (requests[i] != MPI_REQUEST_NULL) {
      printf("Nonnull request in %s\n",msg);
    }
  }
  return;
}
