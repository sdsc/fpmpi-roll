/* 
   This is an example program that shows the serialization when blocking
   communication is used to implement a neighbor exchange.
 */
#include <stdio.h>
#include <stdlib.h>
#include "mpi.h"

int main( int argc, char *argv[] )
{
    double *sbufs, *rbufs;
    MPI_Request r[8];
    int    n = 10000, nbrs = 4;
    int    size, rank, dims[2], px, py;
    int    top, bottom, left, right;

    MPI_Init( &argc, &argv );

    /* Make sure everyone starts at about the same time.  This isn't necessary,
       but is used to reduce noise in the profiling output.  */
    MPI_Barrier( MPI_COMM_WORLD );

    sbufs = (double *)malloc( n * nbrs * sizeof(double) );
    rbufs = (double *)malloc( n * nbrs * sizeof(double) );

    MPI_Comm_size( MPI_COMM_WORLD, &size );
    MPI_Comm_rank( MPI_COMM_WORLD, &rank );
    dims[0] = 0; dims[1] = 0;
    MPI_Dims_create( size, 2, dims );

    /* dims[0] is x, dims[1] is y*/
    /* rank = py * dims[0] + px */
    px = rank % dims[0];
    py = rank / dims[0];
    if (py == dims[1]-1) top = MPI_PROC_NULL;
    else top = (py + 1) * dims[0] + px;
    if (py == 0) bottom = MPI_PROC_NULL;
    else bottom = (py - 1) * dims[0] + px;

    if (px == dims[0]-1) right = MPI_PROC_NULL;
    else right = py * dims[0] + px + 1;
    if (px == 0) left = MPI_PROC_NULL;
    else left = py * dims[0] + px - 1;

    /* Do the nbr exchanges */
    MPI_Isend( sbufs, n, MPI_DOUBLE, bottom, 0, MPI_COMM_WORLD, &r[0] );
    MPI_Irecv( rbufs, n, MPI_DOUBLE, top, 0, MPI_COMM_WORLD, &r[1] );
    MPI_Isend( sbufs+n, n, MPI_DOUBLE, top, 0, MPI_COMM_WORLD, &r[2] );
    MPI_Irecv( rbufs+n, n, MPI_DOUBLE, bottom, 0, MPI_COMM_WORLD, &r[3] );
    MPI_Isend( sbufs+2*n, n, MPI_DOUBLE, left, 0, MPI_COMM_WORLD, &r[4] );
    MPI_Irecv( rbufs+2*n, n, MPI_DOUBLE, right, 0, MPI_COMM_WORLD, &r[5] );
    MPI_Isend( sbufs+3*n, n, MPI_DOUBLE, right, 0, MPI_COMM_WORLD, &r[6] );
    MPI_Irecv( rbufs+3*n, n, MPI_DOUBLE, left, 0, MPI_COMM_WORLD, &r[7] );
    MPI_Waitall( 8, r, MPI_STATUSES_IGNORE );
    
    free( sbufs );
    free( rbufs );

    MPI_Finalize();

    return 0;
}
