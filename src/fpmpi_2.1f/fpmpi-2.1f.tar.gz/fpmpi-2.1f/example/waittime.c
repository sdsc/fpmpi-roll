#include "mpi.h"
#include <stdio.h>
#include <stdlib.h>

/* 
 * This is an example program that shows how the fpmpi2 features to measure
 * syncronization delay may be used to understand and tune a program
 */
int main( int argc, char *argv[] )
{
    int rank, size, i;
    MPI_Comm  comm;
    int delayCount = 1000000;
    int sbuf[10], rbuf[10];

    MPI_Init( &argc, &argv );

    if (argc > 1) {
	delayCount = 0;
    }
    
    comm = MPI_COMM_WORLD;
    MPI_Comm_rank( MPI_COMM_WORLD, &rank );
    MPI_Comm_size( MPI_COMM_WORLD, &size );
    if (rank == 0) printf( "Running with a delaycount of %d\n", delayCount );

    for (i=0; i<10; i++) sbuf[i] = 0;

    /* Make sure everyone is at the same point */
    MPI_Barrier( comm );

    /* First, an example of a load imbalance that shows up in an Allreduce */
    if (rank < 2) {
	sbuf[0] = 1;
	for (i=0; i<delayCount; i++) sbuf[0] ++;
    }
    MPI_Allreduce( sbuf, rbuf, 10, MPI_INT, MPI_SUM, comm );
    
    /* Now, do the same thing with MPI_Recv; that is let one process start 
       the MPI_Recv long before the matching process does the matching send */
    if (rank < 2) {
	if (rank == 0) {
	    sbuf[0] = 1;
	    for (i=0; i<delayCount; i++) sbuf[0] ++;

	    MPI_Send( sbuf, 10, MPI_INT, 1, 0, comm );
	}
	else if (rank == 1) {
	    MPI_Recv( rbuf, 10, MPI_INT, 0, 0, comm, MPI_STATUS_IGNORE );
	}
    }

    /* Now, do the same thing with MPI_Send,  that is let one process start 
       the MPI_Recv long before the matching process does the matching send */
    MPI_Barrier( MPI_COMM_WORLD );
    if (rank < 2) {
	if (rank == 0) {
	    sbuf[0] = 1;
	    for (i=0; i<delayCount; i++) sbuf[0] ++;
	    MPI_Recv( rbuf, 10, MPI_INT, 1, 0, comm, MPI_STATUS_IGNORE );

	}
	else if (rank == 1) {
	    MPI_Send( sbuf, 10, MPI_INT, 0, 0, comm );
	}
    }
    
    MPI_Finalize( );

    return 0;
}
