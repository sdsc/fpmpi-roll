#include "mpi.h"
#include <stdio.h>
#include <stdlib.h>
#define MAX_PROCS 1000
#define BIG_SIZE 10
int main( int argc, char *argv[])
{
    int myid, myright, myleft, numprocs, i;
    int  namelen;
    int ierr;

    double dbl_array[BIG_SIZE] = {0};
    double gen_array[MAX_PROCS][BIG_SIZE] = {{0}};

    char processor_name[MPI_MAX_PROCESSOR_NAME];
    char *string_to_send, *string_to_recv;
    int string_sz = 30;
    MPI_Status status;

    MPI_Init(&argc,&argv);
    MPI_Comm_size(MPI_COMM_WORLD,&numprocs);
    MPI_Comm_rank(MPI_COMM_WORLD,&myid);
    MPI_Get_processor_name(processor_name,&namelen);

    fprintf(stderr,"[%d] on %s\n", myid, processor_name);
    fflush( stderr );

    for (i=0; i < BIG_SIZE; i++ )
      dbl_array[i] = (double) (BIG_SIZE*myid + i);
    
    ierr =  MPI_Gather(dbl_array, BIG_SIZE, MPI_DOUBLE,
		       gen_array, BIG_SIZE, MPI_DOUBLE, 0, MPI_COMM_WORLD);

    ierr = MPI_Barrier( MPI_COMM_WORLD );

    /* Everyone print to myid + 1, except proc numprocs sends to 0 */
    myright = myid + 1;
    if (myright == numprocs) myright = 0;
    myleft = myid - 1;
    if (myleft < 0) myleft = numprocs - 1;

    string_to_send = (char *) malloc(30*sizeof(char));
    string_to_recv = (char *) malloc(30*sizeof(char));

    sprintf(string_to_send, "This is the text for [%d].", myid);

    for (i=1;i<100;i++) {
      ierr = MPI_Send( string_to_send, string_sz, MPI_CHAR, myright, 
		       myid, MPI_COMM_WORLD );
      /* Everyone expects a message from myid-1 of tag myid */
      ierr = MPI_Recv( string_to_recv, string_sz, MPI_CHAR, myleft, myleft, 
		       MPI_COMM_WORLD, &status);
    }

    MPI_Finalize();
    return 0;
}

            
