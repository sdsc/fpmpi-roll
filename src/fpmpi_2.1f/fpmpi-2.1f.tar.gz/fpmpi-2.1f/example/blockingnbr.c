/* 
   This is an example program that shows the serialization when blocking
   communication is used to implement a neighbor exchange.
 */
#include <stdio.h>
#include <stdlib.h>
#include "mpi.h"

int main( int argc, char *argv[] )
{
    double *sbufs, *rbufs;
    int    n = 10000, nbrs = 2;
    int    size, rank;
    int    top, bottom;

    MPI_Init( &argc, &argv );

    /* Make sure everyone starts at about the same time.  This isn't necessary,
       but is used to reduce noise in the profiling output.  */
    MPI_Barrier( MPI_COMM_WORLD );

    sbufs = (double *)malloc( n * nbrs * sizeof(double) );
    rbufs = (double *)malloc( n * nbrs * sizeof(double) );

    MPI_Comm_size( MPI_COMM_WORLD, &size );
    MPI_Comm_rank( MPI_COMM_WORLD, &rank );
    if (rank == size-1) top = MPI_PROC_NULL;
    else top = rank + 1;
    if (rank == 0) bottom = MPI_PROC_NULL;
    else bottom = rank - 1;

    /* Do the nbr exchanges */
    MPI_Send( sbufs, n, MPI_DOUBLE, bottom, 0, MPI_COMM_WORLD );
    MPI_Recv( rbufs, n, MPI_DOUBLE, top, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE );
    MPI_Send( sbufs, n, MPI_DOUBLE, top, 0, MPI_COMM_WORLD );
    MPI_Recv( rbufs, n, MPI_DOUBLE, bottom, 0, MPI_COMM_WORLD, 
	      MPI_STATUS_IGNORE );
    
    free( sbufs );
    free( rbufs );

    MPI_Finalize();

    return 0;
}
