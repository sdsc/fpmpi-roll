/*
 * This is a new file to output the summary information accumulated by
 * fpmpi
 *
 * The goal is to make the output more readable, while maintaining the
 * extra level of detail that fpmpi2 provides
 *
 * Output Format:
 * Assume an 80 character line
 * Summary
 * routine #calls bytes-sent time-distribution(min/where max/where) 
 *
 * Message details
 * routine #calls bytes-sent bins
 *
 */

/* 
 * Data for communication
 * Each profiling communication function has a private CommData object
 */
