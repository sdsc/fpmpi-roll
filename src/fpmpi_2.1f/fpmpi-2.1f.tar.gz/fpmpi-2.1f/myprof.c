/* 
 * This file provides an interface that converts Fortran MPI calls into their
 *
 * 
 * If not building for MPICH, then MPIR_ERROR and the mpi_iargc_/mpir_getarg_
 * calls need to be replaced.
 */

#include "fpmpiconf.h"
#include "mpi.h"
#include <string.h>

#ifndef HAVE_MPI_F2C
/* These will work for many MPI implementations (but not all) */
#define MPI_Comm_c2f(comm) (MPI_Fint)(comm)
#define MPI_Comm_f2c(comm) (MPI_Comm)(comm)
#define MPI_Type_c2f(datatype) (MPI_Fint)(datatype)
#define MPI_Type_f2c(datatype) (MPI_Datatype)(datatype)
#define MPI_Group_c2f(group) (MPI_Fint)(group)
#define MPI_Group_f2c(group) (MPI_Group)(group)
#define MPI_Request_c2f(request) (MPI_Fint)(request)
#define MPI_Request_f2c(request) (MPI_Request)(request)
#define MPI_Op_c2f(op) (MPI_Fint)(op)
#define MPI_Op_f2c(op) (MPI_Op)(op)
#define MPI_Errhandler_c2f(errhandler) (MPI_Fint)(errhandler)
#define MPI_Errhandler_f2c(errhandler) (MPI_Errhandler)(errhandler)
#endif

#if !defined(HAVE_MPI_STATUS_C2F) && !defined(MPI_Status_c2f)
#define MPI_Status_c2f(c_ptr,f_ptr) memcpy( f_ptr, c_ptr, sizeof(MPI_Status) )
#endif

#ifndef HAVE_MPI_FINT
/* Best guess.  A more complex approach could look at the datatype sizes */
typedef int MPI_Fint;
#endif

/* If there is no ERR_NOMEM (defined by MPICH but not a real MPI error class,
   use ERR_INTERN */
/* FIXME: In MPI-2 case, we could use the MPI_Add_error_class and code 
   routines */
#ifndef MPI_ERR_NOMEM
#define MPI_ERR_NOMEM MPI_ERR_INTERN
#endif

#ifndef MPI_STATUS_SIZE
#define MPI_STATUS_SIZE SIZEOF_MPI_STATUS_IN_INTS
#endif
static int status_size_ok = -1;

#define MPIR_F_PTR(a) (a)

/* We must convert to and from Fortran logicals.  In some cases, we
 can determine at configure time what the values are */
#ifdef F77_TRUE_VALUE_SET
#define MPIR_TO_FLOG(a) ((a) ? F77_TRUE_VALUE : F77_FALSE_VALUE)
#else
static MPI_Fint MPIR_F_TRUE, MPIR_F_FALSE;
#define MPIR_TO_FLOG(a) ((a) ? MPIR_F_TRUE : MPIR_F_FALSE)
#endif

/*#ifndef MPICH_NAME*/
/* If we aren't running MPICH, just use fprintf for errors */
#include <stdio.h>
#define MPIR_ERROR(comm,errcode,str) (fprintf(stderr,"%s\n",str),errcode)
/*#endif*/

/* Also avoid Fortran arguments */
/*#define mpir_iargc_() 0 */
/* #define mpir_getarg_( idx, str, ln ) strncpy(str,"Unknown",ln) */
/* Make sure that we get the correct Fortran form */

#ifdef F77_NAME_UPPER
#define mpir_iargc_ MPIR_IARGC
#define mpir_getarg_ MPIR_GETARG
#define fpmpi_init_flog_ FPMPI_INIT_FLOG
#elif defined(F77_NAME_LOWER_2USCORE)
#define mpir_iargc_ mpir_iargc__
#define mpir_getarg_ mpir_getarg__
#define fpmpi_init_flog fpmpi_init_flog__
#elif !defined(F77_NAME_LOWER_USCORE)
#define mpir_iargc_ mpir_iargc
#define mpir_getarg_ mpir_getarg
#define fpmpi_init_flog_ fpmpi_init_flog
#endif

#ifdef HAVE_STDLIB_H
#include <stdlib.h>
#endif

#ifdef F77_NAME_UPPER
#define mpi_init_ MPI_INIT
#define mpi_bsend_ MPI_BSEND
#define mpi_get_count_ MPI_GET_COUNT
#define mpi_ibsend_ MPI_IBSEND
#define mpi_irecv_ MPI_IRECV
#define mpi_irsend_ MPI_IRSEND
#define mpi_isend_ MPI_ISEND
#define mpi_issend_ MPI_ISSEND
#define mpi_recv_ MPI_RECV
#define mpi_rsend_ MPI_RSEND
#define mpi_send_ MPI_SEND
#define mpi_sendrecv_ MPI_SENDRECV
#define mpi_sendrecv_replace_ MPI_SENDRECV_REPLACE
#define mpi_ssend_ MPI_SSEND
#define mpi_test_ MPI_TEST
#define mpi_testall_ MPI_TESTALL
#define mpi_testany_ MPI_TESTANY
#define mpi_testsome_ MPI_TESTSOME
#define mpi_allgather_ MPI_ALLGATHER
#define mpi_allgatherv_ MPI_ALLGATHERV
#define mpi_allreduce_ MPI_ALLREDUCE
#define mpi_alltoall_ MPI_ALLTOALL
#define mpi_alltoallv_ MPI_ALLTOALLV
#define mpi_barrier_ MPI_BARRIER
#define mpi_bcast_ MPI_BCAST
#define mpi_gather_ MPI_GATHER
#define mpi_gatherv_ MPI_GATHERV
#define mpi_pack_ MPI_PACK
#define mpi_reduce_scatter_ MPI_REDUCE_SCATTER
#define mpi_reduce_ MPI_REDUCE
#define mpi_scan_ MPI_SCAN
#define mpi_scatter_ MPI_SCATTER
#define mpi_scatterv_ MPI_SCATTERV
#define mpi_finalize_ MPI_FINALIZE
#define mpi_waitall_ MPI_WAITALL
#define mpi_waitany_ MPI_WAITANY
#define mpi_wait_ MPI_WAIT
#define mpi_waitsome_ MPI_WAITSOME
#define mpi_unpack_ MPI_UNPACK
#define mpi_iprobe_ MPI_IPROBE
#define mpi_probe_ MPI_PROBE
#define mpi_comm_dup_ MPI_COMM_DUP
#define mpi_comm_split_ MPI_COMM_SPLIT
#define mpi_comm_free_ MPI_COMM_FREE

/*                                            */
/* These have not yet been added to profiler.c */
/* 
#define mpi_bsend_init_ MPI_BSEND_INIT
#define mpi_buffer_attach_ MPI_BUFFER_ATTACH
#define mpi_buffer_detach_ MPI_BUFFER_DETACH
#define mpi_cancel_ MPI_CANCEL
#define mpi_request_free_ MPI_REQUEST_FREE
#define mpi_recv_init_ MPI_RECV_INIT
#define mpi_send_init_ MPI_SEND_INIT
#define mpi_get_elements_ MPI_GET_ELEMENTS
#define mpi_pack_size_ MPI_PACK_SIZE
#define mpi_rsend_init_ MPI_RSEND_INIT
#define mpi_ssend_init_ MPI_SSEND_INIT
#define mpi_startall_ MPI_STARTALL
#define mpi_start_ MPI_START
#define mpi_test_canceled_ MPI_TESTCANCEL
#define mpi_type_commit_ MPI_TYPE_COMMIT
#define mpi_type_contiguous_ MPI_TYPE_CONTIGUOUS
#define mpi_type_extent_ MPI_TYPE_EXTENT
#define mpi_type_free_ MPI_TYPE_FREE
#define mpi_type_hindexed_ MPI_TYPE_HINDEXED
#define mpi_type_hvector_ MPI_TYPE_HVECTOR
#define mpi_type_indexed_ MPI_TYPE_INDEXED
#define mpi_type_lb_ MPI_TYPE_LB
#define mpi_type_size_ MPI_TYPE_SIZE
#define mpi_type_struct_ MPI_TYPE_STRUCT
#define mpi_type_ub_ MPI_TYPE_UB
#define mpi_type_vector_ MPI_TYPE_VECTOR
#define mpi_op_create_ MPI_OP_CREATE
#define mpi_op_free_ MPI_OP_FREE
*/
#elif defined(F77_NAME_LOWER_2USCORE)
#define mpi_init_ mpi_init__
#define mpi_bsend_ mpi_bsend__
#define mpi_get_count_ mpi_get_count__
#define mpi_ibsend_ mpi_ibsend__
#define mpi_irecv_ mpi_irecv__
#define mpi_irsend_ mpi_irsend__
#define mpi_isend_ mpi_isend__
#define mpi_issend_ mpi_issend__
#define mpi_pack_ mpi_pack__
#define mpi_recv_ mpi_recv__
#define mpi_rsend_ mpi_rsend__
#define mpi_send_ mpi_send__
#define mpi_sendrecv_ mpi_sendrecv__
#define mpi_sendrecv_replace_ mpi_sendrecv_replace__
#define mpi_ssend_ mpi_ssend__
#define mpi_test_ mpi_test__
#define mpi_testall_ mpi_testall__
#define mpi_testany_ mpi_testany__
#define mpi_testsome_ mpi_testsome__
#define mpi_allgather_ mpi_allgather__
#define mpi_allgatherv_ mpi_allgatherv__
#define mpi_allreduce_ mpi_allreduce__
#define mpi_alltoall_ mpi_alltoall__
#define mpi_alltoallv_ mpi_alltoallv__
#define mpi_barrier_ mpi_barrier__
#define mpi_bcast_ mpi_bcast__
#define mpi_gather_ mpi_gather__
#define mpi_gatherv_ mpi_gatherv__
#define mpi_reduce_scatter_ mpi_reduce_scatter__
#define mpi_reduce_ mpi_reduce__
#define mpi_scan_ mpi_scan__
#define mpi_scatter_ mpi_scatter__
#define mpi_scatterv_ mpi_scatterv__
#define mpi_waitall_ mpi_waitall__
#define mpi_waitany_ mpi_waitany__
#define mpi_wait_ mpi_wait__
#define mpi_waitsome_ mpi_waitsome__
#define mpi_unpack_ mpi_unpack__
#define mpi_finalize_ mpi_finalize__
#define mpi_iprobe_ mpi_iprobe__
#define mpi_probe_ mpi_probe__
#define mpi_comm_dup_ mpi_comm_dup__
#define mpi_comm_split_ mpi_comm_split__
#define mpi_comm_free_ mpi_comm_free__
/*                                            */
/* These have not yet been added to profiler.c */
/* 
#define mpi_bsend_init_ mpi_bsend_init__
#define mpi_buffer_attach_ mpi_buffer_attach__
#define mpi_buffer_detach_ mpi_buffer_detach__
#define mpi_cancel_ mpi_cancel__
#define mpi_request_free_ mpi_request_free__
#define mpi_recv_init_ mpi_recv_init__
#define mpi_send_init_ mpi_send_init__
#define mpi_get_elements_ mpi_get_elements__
#define mpi_pack_size_ mpi_pack_size__
#define mpi_rsend_init_ mpi_rsend_init__
#define mpi_ssend_init_ mpi_ssend_init__
#define mpi_startall_ mpi_startall__
#define mpi_start_ mpi_start__
#define mpi_test_cancelled_ mpi_test_cancelled__
#define mpi_type_commit_ mpi_type_commit__
#define mpi_type_contiguous_ mpi_type_contiguous__
#define mpi_type_extent_ mpi_type_extent__
#define mpi_type_free_ mpi_type_free__
#define mpi_type_hindexed_ mpi_type_hindexed__
#define mpi_type_hvector_ mpi_type_hvector__
#define mpi_type_indexed_ mpi_type_indexed__
#define mpi_type_lb_ mpi_type_lb__
#define mpi_type_size_ mpi_type_size__
#define mpi_type_struct_ mpi_type_struct__
#define mpi_type_ub_ mpi_type_ub__
#define mpi_type_vector_ mpi_type_vector__
#define mpi_op_create_ mpi_op_create__
#define mpi_op_free_ mpi_op_free__
*/
#elif defined(F77_NAME_LOWER)
#define mpi_bsend_ mpi_bsend
#define mpi_init_ mpi_init
#define mpi_get_count_ mpi_get_count
#define mpi_ibsend_ mpi_ibsend
#define mpi_irecv_ mpi_irecv
#define mpi_irsend_ mpi_irsend
#define mpi_isend_ mpi_isend
#define mpi_issend_ mpi_issend
#define mpi_recv_ mpi_recv
#define mpi_pack_ mpi_pack
#define mpi_rsend_ mpi_rsend
#define mpi_send_ mpi_send
#define mpi_sendrecv_ mpi_sendrecv
#define mpi_sendrecv_replace_ mpi_sendrecv_replace
#define mpi_ssend_ mpi_ssend
#define mpi_test_ mpi_test
#define mpi_testall_ mpi_testall
#define mpi_testany_ mpi_testany
#define mpi_testsome_ mpi_testsome
#define mpi_allgather_ mpi_allgather
#define mpi_allgatherv_ mpi_allgatherv
#define mpi_allreduce_ mpi_allreduce
#define mpi_alltoall_ mpi_alltoall
#define mpi_alltoallv_ mpi_alltoallv
#define mpi_barrier_ mpi_barrier
#define mpi_bcast_ mpi_bcast
#define mpi_gather_ mpi_gather
#define mpi_gatherv_ mpi_gatherv
#define mpi_reduce_scatter_ mpi_reduce_scatter
#define mpi_reduce_ mpi_reduce
#define mpi_scan_ mpi_scan
#define mpi_scatter_ mpi_scatter
#define mpi_scatterv_ mpi_scatterv
#define mpi_waitall_ mpi_waitall
#define mpi_waitany_ mpi_waitany
#define mpi_wait_ mpi_wait
#define mpi_waitsome_ mpi_waitsome
#define mpi_unpack_ mpi_unpack
#define mpi_finalize_ mpi_finalize
#define mpi_iprobe_ mpi_iprobe
#define mpi_probe_ mpi_probe
#define mpi_comm_dup_ mpi_comm_dup
#define mpi_comm_split_ mpi_comm_split
#define mpi_comm_free_ mpi_comm_free
/*                                            */
/* These have not yet been added to profiler.c */
/* 
#define mpi_bsend_init_ mpi_bsend_init
#define mpi_buffer_attach_ mpi_buffer_attach
#define mpi_buffer_detach_ mpi_buffer_detach
#define mpi_cancel_ mpi_cancel
#define mpi_request_free_ mpi_request_free
#define mpi_recv_init_ mpi_recv_init
#define mpi_send_init_ mpi_send_init
#define mpi_get_elements_ mpi_get_elements
#define mpi_pack_size_ mpi_pack_size
#define mpi_rsend_init_ mpi_rsend_init
#define mpi_ssend_init_ mpi_ssend_init
#define mpi_startall_ mpi_startall
#define mpi_start_ mpi_start
#define mpi_test_cancelled_ mpi_test_cancelled
#define mpi_type_commit_ mpi_type_commit
#define mpi_type_contiguous_ mpi_type_contiguous
#define mpi_type_extent_ mpi_type_extent
#define mpi_type_free_ mpi_type_free
#define mpi_type_hindexed_ mpi_type_hindexed
#define mpi_type_hvector_ mpi_type_hvector
#define mpi_type_indexed_ mpi_type_indexed
#define mpi_type_lb_ mpi_type_lb
#define mpi_type_size_ mpi_type_size
#define mpi_type_struct_ mpi_type_struct
#define mpi_type_ub_ mpi_type_ub
#define mpi_type_vector_ mpi_type_vector
#define mpi_op_create_ mpi_op_create
#define mpi_op_free_ mpi_op_free
*/
#endif

/*
 * Define prototypes to keep the compiler happy
 */
void STDCALL mpi_init_ ( MPI_Fint * );
void STDCALL mpi_bsend_ (void *, MPI_Fint *, MPI_Fint *, MPI_Fint *, MPI_Fint *,
			   MPI_Fint *, MPI_Fint *);
void STDCALL mpi_get_count_ (MPI_Fint *, MPI_Fint *, MPI_Fint *, MPI_Fint *);
void STDCALL mpi_ibsend_ (void *, MPI_Fint *, MPI_Fint *, MPI_Fint *, MPI_Fint *, 
		  MPI_Fint *, MPI_Fint *, MPI_Fint *);
void STDCALL mpi_irecv_ (void *, MPI_Fint *, MPI_Fint *, MPI_Fint *, MPI_Fint *, 
		 MPI_Fint *, MPI_Fint *, MPI_Fint * );
void STDCALL mpi_irsend_ (void *, MPI_Fint *, MPI_Fint *, MPI_Fint *, MPI_Fint *,
		  MPI_Fint *, MPI_Fint *, MPI_Fint *);
void STDCALL mpi_isend_ ( void *, MPI_Fint *, MPI_Fint *, MPI_Fint *, MPI_Fint *, 
		  MPI_Fint *, MPI_Fint *, MPI_Fint * );
void STDCALL mpi_issend_ (void *, MPI_Fint *, MPI_Fint *, MPI_Fint *, MPI_Fint *,
		  MPI_Fint *, MPI_Fint *, MPI_Fint *);
void STDCALL mpi_recv_ ( void *, int *, MPI_Fint *, MPI_Fint *, MPI_Fint *, 
		 MPI_Fint *, MPI_Fint *, MPI_Fint * );
void STDCALL mpi_rsend_init_ (void *, MPI_Fint *, MPI_Fint *, MPI_Fint *, MPI_Fint *,
		      MPI_Fint *, MPI_Fint *, MPI_Fint *);
void STDCALL mpi_rsend_ (void *, MPI_Fint *, MPI_Fint *, MPI_Fint *, MPI_Fint *, 
		 MPI_Fint *, MPI_Fint *);
void STDCALL mpi_send_ ( void *, MPI_Fint *, MPI_Fint *, MPI_Fint *, MPI_Fint *, 
		 MPI_Fint *, MPI_Fint * );
void STDCALL mpi_sendrecv_ ( void *, MPI_Fint *, MPI_Fint *, MPI_Fint *, MPI_Fint *,
		     void *, MPI_Fint *, MPI_Fint *, MPI_Fint *, 
		     MPI_Fint *, MPI_Fint *, MPI_Fint *, MPI_Fint * );
void STDCALL mpi_sendrecv_replace_ (void *, MPI_Fint *, MPI_Fint *, MPI_Fint *, 
			    MPI_Fint *, MPI_Fint *, MPI_Fint *, MPI_Fint *, 
			    MPI_Fint *, MPI_Fint *);
void STDCALL mpi_ssend_ ( void *, MPI_Fint *, MPI_Fint *, MPI_Fint *, MPI_Fint *,
			    MPI_Fint *, MPI_Fint * );
void STDCALL mpi_test_ ( MPI_Fint *, MPI_Fint *, MPI_Fint *, MPI_Fint * );
void STDCALL mpi_testall_ (MPI_Fint *, MPI_Fint *, MPI_Fint *, 
		   MPI_Fint array_of_statuses[][MPI_STATUS_SIZE], MPI_Fint *);
void STDCALL mpi_testany_ (MPI_Fint *, MPI_Fint *, MPI_Fint *, MPI_Fint *, 
		   MPI_Fint *, MPI_Fint *);
void STDCALL mpi_testsome_ (MPI_Fint *, MPI_Fint *, MPI_Fint *, MPI_Fint *, 
		    MPI_Fint array_of_statuses[][MPI_STATUS_SIZE], 
		    MPI_Fint *__ierr );
void STDCALL mpi_allgather_ (void *, MPI_Fint *, MPI_Fint *, void *, MPI_Fint *,
		     MPI_Fint *, MPI_Fint *, MPI_Fint *);
void STDCALL mpi_allgatherv_ (void *, MPI_Fint *, MPI_Fint *, void *, MPI_Fint *,
		      MPI_Fint *, MPI_Fint *, MPI_Fint *, MPI_Fint *);
void STDCALL mpi_allreduce_ ( void *, void *, MPI_Fint *, MPI_Fint *, 
		      MPI_Fint *, MPI_Fint *, MPI_Fint * );
void STDCALL mpi_alltoall_ (void *, MPI_Fint *, MPI_Fint *, void *, MPI_Fint *,
		    MPI_Fint *, MPI_Fint *, MPI_Fint *);
void STDCALL mpi_alltoallv_ (void *, MPI_Fint *, MPI_Fint *, MPI_Fint *, void *, 
		     MPI_Fint *, MPI_Fint *, MPI_Fint *, MPI_Fint *,
		     MPI_Fint *);
void STDCALL mpi_barrier_ ( MPI_Fint *, MPI_Fint * );
void STDCALL mpi_bcast_ ( void *, MPI_Fint *, MPI_Fint *, MPI_Fint *, 
		  MPI_Fint *, MPI_Fint * );
void STDCALL mpi_gather_ (void *, MPI_Fint *, MPI_Fint *, void *, MPI_Fint *, 
		  MPI_Fint *, MPI_Fint *, MPI_Fint *, MPI_Fint *);
void STDCALL mpi_gatherv_ (void *, MPI_Fint *, MPI_Fint *, void *, MPI_Fint *,  
		   MPI_Fint *, MPI_Fint *, MPI_Fint *, MPI_Fint *, MPI_Fint *);
void STDCALL mpi_pack_ (void *, MPI_Fint *, MPI_Fint *, void *, MPI_Fint *, MPI_Fint *,
		MPI_Fint *, MPI_Fint *);
void STDCALL mpi_reduce_scatter_ (void *, void *, MPI_Fint *, MPI_Fint *,
			  MPI_Fint *, MPI_Fint *, MPI_Fint *);
void STDCALL mpi_reduce_ ( void *, void *, MPI_Fint *, MPI_Fint *, MPI_Fint *, 
		   MPI_Fint *, MPI_Fint *, MPI_Fint * );
void STDCALL mpi_scan_ (void *, void *, MPI_Fint *, MPI_Fint *, MPI_Fint *,
		MPI_Fint *, MPI_Fint *);
void STDCALL mpi_scatter_ (void *, MPI_Fint *, MPI_Fint *, void *, MPI_Fint *,
		   MPI_Fint *, MPI_Fint *, MPI_Fint *, MPI_Fint *);
void STDCALL mpi_scatterv_ (void *, MPI_Fint *, MPI_Fint *, MPI_Fint *, void *, 
		    MPI_Fint *, MPI_Fint *, MPI_Fint *, MPI_Fint *, 
		    MPI_Fint *);
void STDCALL mpi_waitall_ ( MPI_Fint *, MPI_Fint *, 
		    MPI_Fint array_of_statuses[][MPI_STATUS_SIZE], 
		    MPI_Fint *__ierr );
void STDCALL mpi_waitany_ ( MPI_Fint *, MPI_Fint *, MPI_Fint *, MPI_Fint *, 
		    MPI_Fint * );
void STDCALL mpi_wait_ ( MPI_Fint *, MPI_Fint *, MPI_Fint * );
void STDCALL mpi_waitsome_ (MPI_Fint *, MPI_Fint *, MPI_Fint *, MPI_Fint *,
		    MPI_Fint array_of_statuses[][MPI_STATUS_SIZE], 
		    MPI_Fint *__ierr );
void STDCALL mpi_unpack_ (void *, MPI_Fint *, MPI_Fint *, void *, MPI_Fint *, 
		  MPI_Fint *, MPI_Fint *, MPI_Fint *);
void STDCALL mpi_finalize_ ( MPI_Fint * );
void STDCALL mpi_iprobe_ (MPI_Fint *, MPI_Fint *, MPI_Fint *, MPI_Fint *, MPI_Fint *,
                  MPI_Fint *);
void STDCALL mpi_probe_ (MPI_Fint *, MPI_Fint *, MPI_Fint *, MPI_Fint *, MPI_Fint *);
void STDCALL mpi_comm_dup_ (MPI_Fint *, MPI_Fint *, MPI_Fint *);
void STDCALL mpi_comm_split_ (MPI_Fint *, MPI_Fint *, MPI_Fint *, MPI_Fint *, MPI_Fint *);
void STDCALL mpi_comm_free_( MPI_Fint *, MPI_Fint *);
/*                                            */
/* These have not yet been added to profiler.c */
/* 
void STDCALL mpi_bsend_init_ (void *, MPI_Fint *, MPI_Fint *, MPI_Fint *, MPI_Fint *,
                      MPI_Fint *, MPI_Fint *, MPI_Fint *);
void STDCALL mpi_buffer_attach_ (void *, MPI_Fint *, MPI_Fint *);
void STDCALL mpi_buffer_detach_ (void *, MPI_Fint *, MPI_Fint *);
void STDCALL mpi_cancel_ (MPI_Fint *, MPI_Fint *);
void STDCALL mpi_request_free_ (MPI_Fint *, MPI_Fint *);
void STDCALL mpi_recv_init_ (void *, MPI_Fint *, MPI_Fint *, MPI_Fint *, MPI_Fint *,
			       MPI_Fint *, MPI_Fint *, MPI_Fint *);
void STDCALL mpi_send_init_ (void *, MPI_Fint *, MPI_Fint *, MPI_Fint *, MPI_Fint *,
			       MPI_Fint *, MPI_Fint *, MPI_Fint *);
void STDCALL mpi_get_elements_ (MPI_Fint *, MPI_Fint *, MPI_Fint *, MPI_Fint *);
void STDCALL mpi_pack_size_ (MPI_Fint *, MPI_Fint *, MPI_Fint *, MPI_Fint *, 
		     MPI_Fint *);
void STDCALL mpi_ssend_init_ (void *, MPI_Fint *, MPI_Fint *, MPI_Fint *, MPI_Fint *,
		      MPI_Fint *, MPI_Fint *, MPI_Fint *);
void STDCALL mpi_startall_ (MPI_Fint *, MPI_Fint *, MPI_Fint *);
void STDCALL mpi_start_ (MPI_Fint *, MPI_Fint *);
void STDCALL mpi_test_cancelled_ (MPI_Fint *, MPI_Fint *, MPI_Fint *);
void STDCALL mpi_type_commit_ (MPI_Fint *, MPI_Fint *);
void STDCALL mpi_type_contiguous_ (MPI_Fint *, MPI_Fint *, MPI_Fint *,
				     MPI_Fint *);
void STDCALL mpi_type_extent_ (MPI_Fint *, MPI_Aint *, MPI_Fint *);
void STDCALL mpi_type_free_ (MPI_Fint *, MPI_Fint *);
void STDCALL mpi_type_hindexed_ (MPI_Fint *, MPI_Fint *, MPI_Aint *, MPI_Fint *,
				   MPI_Fint *, MPI_Fint *);
void STDCALL mpi_type_hvector_ (MPI_Fint *, MPI_Fint *, MPI_Aint *, MPI_Fint *,
				  MPI_Fint *, MPI_Fint *);
void STDCALL mpi_type_indexed_ (MPI_Fint *, MPI_Fint *, MPI_Fint *, MPI_Fint *,
				  MPI_Fint *, MPI_Fint *);
void STDCALL mpi_type_lb_ (MPI_Fint *, MPI_Aint *, MPI_Fint *);
void STDCALL mpi_type_size_ (MPI_Fint *, MPI_Fint *, MPI_Fint *);
void STDCALL mpi_type_struct_ (MPI_Fint *, MPI_Fint *, MPI_Aint *, MPI_Fint *,
				 MPI_Fint *, MPI_Fint *);
void STDCALL mpi_type_ub_ (MPI_Fint *, MPI_Aint *, MPI_Fint *);
void STDCALL mpi_type_vector_ (MPI_Fint *, MPI_Fint *, MPI_Fint *, MPI_Fint *,
				 MPI_Fint *, MPI_Fint *);
void STDCALL mpi_op_create_ (MPI_User_function *, MPI_Fint *, MPI_Op *, MPI_Fint *);
void STDCALL mpi_op_free_ (MPI_Op *, MPI_Fint *);
*/

/* Lets hope that the Fortran MPI_Init calls the C MPI_Init... */

/*
 * 
 */
#ifdef NEEDS_FORTRAN_MPI_INIT
void STDCALL mpi_init_( MPI_Fint *ierr )
{
    int Argc;
    int i, argsize = 1024;
    char **Argv, *p;
    int  ArgcSave;           /* Save the argument count */
    char **ArgvSave;         /* Save the pointer to the argument vector */
    char **ArgvValSave;      /* Save entries in the argument vector */

/* Recover the args with the Fortran routines iargc_ and getarg_ */
    ArgcSave	= Argc = mpir_iargc_() + 1; 
    ArgvSave	= Argv = (char **)malloc( Argc * sizeof(char *) );    
    ArgvValSave = (char**)malloc( Argc * sizeof(char *) );
    if (!Argv) {
	*ierr = MPIR_ERROR( (MPI_Comm)0, MPI_ERR_OTHER, 
			    "Out of space in MPI_INIT" );
	return;
    }
    for (i=0; i<Argc; i++) {
	ArgvValSave[i] = Argv[i] = (char *)malloc( argsize + 1 );
	if (!Argv[i]) {
	    *ierr = MPIR_ERROR( (MPI_Comm)0, MPI_ERR_OTHER, 
				"Out of space in MPI_INIT" );
	    return;
        }
	mpir_getarg_( &i, Argv[i], argsize );

	/* Trim trailing blanks */
	p = Argv[i] + argsize - 1;
	while (p > Argv[i]) {
	    if (*p != ' ') {
		p[1] = '\0';
		break;
	    }
	    p--;
	}
    }

    *ierr = MPI_Init( &Argc, &Argv );
    
    /* Recover space */
    for (i=0; i<ArgcSave; i++) {
	free( ArgvValSave[i] );
    }
    free( ArgvValSave );
    free( ArgvSave );

#ifndef  F77_TRUE_VALUE_SET
    /* Get the values of the Fortran logicals */
    fpmpi_init_flog_( &MPIR_F_TRUE, &MPIR_F_FALSE );
#endif
}
#endif

void STDCALL mpi_bsend_( void *buf, MPI_Fint *count, MPI_Fint *datatype, 
		 MPI_Fint *dest, 
		 MPI_Fint *tag, MPI_Fint *comm, MPI_Fint *__ierr )
{
  *__ierr = MPI_Bsend(buf,*count,MPI_Type_f2c(*datatype),*dest,*tag,
		      MPI_Comm_f2c(*comm) );
}

void STDCALL mpi_ibsend_( void *buf, MPI_Fint *count, MPI_Fint *datatype, 
		  MPI_Fint *dest, MPI_Fint *tag, MPI_Fint *comm,
		  MPI_Fint *request, MPI_Fint *__ierr )
{
    MPI_Request lrequest;
    *__ierr = MPI_Ibsend(MPIR_F_PTR(buf),(int)*count,MPI_Type_f2c(*datatype),
                         (int)*dest,(int)*tag,MPI_Comm_f2c(*comm),
                         &lrequest);
    *request = MPI_Request_c2f(lrequest);
}

void STDCALL mpi_irecv_( void *buf, MPI_Fint *count, MPI_Fint *datatype, 
		 MPI_Fint *source, MPI_Fint *tag, MPI_Fint *comm, 
		 MPI_Fint *request, MPI_Fint *__ierr )
{
    MPI_Request lrequest;
    *__ierr = MPI_Irecv(MPIR_F_PTR(buf),(int)*count,MPI_Type_f2c(*datatype),
			(int)*source,(int)*tag,
                        MPI_Comm_f2c(*comm),&lrequest);
    *request = MPI_Request_c2f(lrequest);
}

void STDCALL mpi_irsend_( void *buf, MPI_Fint *count, MPI_Fint *datatype, 
		  MPI_Fint *dest, MPI_Fint *tag, MPI_Fint *comm, 
		  MPI_Fint *request, MPI_Fint *__ierr )
{
    MPI_Request lrequest;
    *__ierr = MPI_Irsend(MPIR_F_PTR(buf),(int)*count,MPI_Type_f2c(*datatype),
			 (int)*dest,(int)*tag,
			 MPI_Comm_f2c(*comm),&lrequest);
    *request = MPI_Request_c2f(lrequest);
}

void STDCALL mpi_isend_( void *buf, MPI_Fint *count, MPI_Fint *datatype, 
		 MPI_Fint *dest, MPI_Fint *tag, MPI_Fint *comm, 
		 MPI_Fint *request, MPI_Fint *__ierr )
{
    MPI_Request lrequest;
    *__ierr = MPI_Isend(MPIR_F_PTR(buf),(int)*count, MPI_Type_f2c(*datatype),
                        (int)*dest,
                        (int)*tag, MPI_Comm_f2c(*comm),
			&lrequest);
    *request = MPI_Request_c2f(lrequest);
}

void STDCALL mpi_issend_( void *buf, MPI_Fint *count, MPI_Fint *datatype, 
		  MPI_Fint *dest, MPI_Fint *tag, MPI_Fint *comm, 
		  MPI_Fint *request, MPI_Fint *__ierr )
{
    MPI_Request lrequest;
    *__ierr = MPI_Issend(MPIR_F_PTR(buf),(int)*count,MPI_Type_f2c(*datatype),
                         (int)*dest, (int)*tag,
                         MPI_Comm_f2c(*comm),
			 &lrequest);
    *request = MPI_Request_c2f(lrequest);
}

void STDCALL mpi_pack_ ( void *inbuf, MPI_Fint *incount, MPI_Fint *type, void *outbuf,
		 MPI_Fint *outcount, MPI_Fint *position, MPI_Fint *comm, 
		 MPI_Fint *__ierr )
{
    *__ierr = MPI_Pack(inbuf, *incount, MPI_Type_f2c(*type), outbuf, 
		       *outcount, position,
                       MPI_Comm_f2c(*comm) );
}

void STDCALL mpi_recv_( void *buf, MPI_Fint *count, MPI_Fint *datatype, 
		MPI_Fint *source, MPI_Fint *tag, MPI_Fint *comm, 
		MPI_Fint *status, MPI_Fint *__ierr )
{
  MPI_Status s;
  /* A local status should be used if MPI_Fint and int are different sizes */
    *__ierr = MPI_Recv(buf, *count, MPI_Type_f2c(*datatype), *source, *tag, 
		       MPI_Comm_f2c(*comm), &s );
#ifdef HAVE_MPI_F_STATUS_IGNORE
  if (status != MPI_F_STATUS_IGNORE)
#endif
    MPI_Status_c2f( &s, status );
}

void STDCALL mpi_rsend_( void *buf, MPI_Fint *count, MPI_Fint *datatype, 
		 MPI_Fint *dest, MPI_Fint *tag, MPI_Fint *comm, 
		 MPI_Fint *__ierr )
{
    *__ierr = MPI_Rsend(buf, *count, MPI_Type_f2c(*datatype), *dest, *tag, 
			MPI_Comm_f2c(*comm) );
}

void STDCALL mpi_send_( void *buf, MPI_Fint *count, MPI_Fint *datatype, MPI_Fint *dest,
		MPI_Fint *tag, MPI_Fint *comm, MPI_Fint *__ierr )
{
    *__ierr = MPI_Send(buf, *count, MPI_Type_f2c(*datatype), *dest, *tag, 
		       MPI_Comm_f2c(*comm) );
}

void STDCALL mpi_sendrecv_( void *sendbuf, MPI_Fint *sendcount, MPI_Fint *sendtype, 
		    MPI_Fint *dest, MPI_Fint *sendtag, 
                    void *recvbuf, MPI_Fint *recvcount, MPI_Fint *recvtype,
		    MPI_Fint *source, MPI_Fint *recvtag, 
                    MPI_Fint *comm, MPI_Fint *status, MPI_Fint *__ierr )
{
  MPI_Status s;
    *__ierr = MPI_Sendrecv(sendbuf, *sendcount, MPI_Type_f2c(*sendtype),
		           *dest,*sendtag,recvbuf,*recvcount,
		           MPI_Type_f2c(*recvtype),*source,*recvtag,
			   MPI_Comm_f2c(*comm),&s);
#ifdef HAVE_MPI_F_STATUS_IGNORE
  if (status != MPI_F_STATUS_IGNORE)
#endif
    MPI_Status_c2f( &s, status );
}

void STDCALL mpi_sendrecv_replace_( void *buf, MPI_Fint *count, MPI_Fint *datatype, 
			    MPI_Fint *dest, MPI_Fint *sendtag, 
			    MPI_Fint *source, 
			    MPI_Fint *recvtag, MPI_Fint *comm, 
			    MPI_Fint *status, MPI_Fint *__ierr )
{
  MPI_Status s;
    *__ierr = MPI_Sendrecv_replace(buf, *count, MPI_Type_f2c(*datatype), 
				   *dest, *sendtag,
				   *source, *recvtag, MPI_Comm_f2c(*comm), 
				   &s );
#ifdef HAVE_MPI_F_STATUS_IGNORE
  if (status != MPI_F_STATUS_IGNORE)
#endif
    MPI_Status_c2f( &s, status );
}

void STDCALL mpi_ssend_( void *buf, MPI_Fint *count, MPI_Fint *datatype, 
		 MPI_Fint *dest, MPI_Fint *tag, MPI_Fint *comm, 
		 MPI_Fint *__ierr )
{
    *__ierr = MPI_Ssend(buf, *count, MPI_Type_f2c(*datatype), *dest, *tag, 
			MPI_Comm_f2c(*comm) );
}

void STDCALL mpi_test_ ( MPI_Fint *request, MPI_Fint *flag, MPI_Fint *status, 
		 MPI_Fint *__ierr )
{
    int        l_flag;
    MPI_Status c_status;
    MPI_Request lrequest = MPI_Request_f2c(*request);

    *__ierr = MPI_Test( &lrequest, &l_flag, &c_status);
    *request = MPI_Request_c2f(lrequest);  /* In case request is changed */

    *flag = MPIR_TO_FLOG(l_flag);
    if (l_flag) {
#ifdef HAVE_MPI_F_STATUS_IGNORE
       if (status != MPI_F_STATUS_IGNORE)
#endif
	  MPI_Status_c2f(&c_status, status);
    }
}

#define FPMPI_LOCAL_ARRAY_SIZE 16
void STDCALL mpi_testall_( MPI_Fint *count, MPI_Fint array_of_requests[], 
		   MPI_Fint *flag,
		   MPI_Fint array_of_statuses[][MPI_STATUS_SIZE],
		   MPI_Fint *__ierr )
{
    int lflag;
    int i;
    MPI_Request *lrequest = 0;
    MPI_Request local_lrequest[FPMPI_LOCAL_ARRAY_SIZE];
    MPI_Status *c_status = 0;
    MPI_Status local_c_status[FPMPI_LOCAL_ARRAY_SIZE];

    if (status_size_ok == -1) {
	if (MPI_STATUS_SIZE != sizeof(MPI_Status)/sizeof(int)) {
	    /* Warning - */
	    fprintf( stderr, "Warning: The Fortran fpmpi code expected the sizeof MPI_Status\n\
 to be %d integers but it is %d.  Rebuild fpmpi and make sure that the\n\
 correct value is found and set in the fpmpiconf.h file\n", MPI_STATUS_SIZE,
		     (int)(sizeof(MPI_Status)/sizeof(int)) );
	    status_size_ok = 0;
	}
	else 
	    status_size_ok = 1;
    }
    if ((int)*count > 0) {
        if ((int)*count > FPMPI_LOCAL_ARRAY_SIZE) {
            lrequest = (MPI_Request*)malloc(sizeof(MPI_Request)* (int)*count);
	    if (!lrequest) {*__ierr = MPI_ERR_NOMEM; return; }
            c_status = (MPI_Status*)malloc(sizeof(MPI_Status)* (int)*count);
	    if (!c_status) { *__ierr = MPI_ERR_NOMEM; return; }
        }
        else {
	    lrequest = local_lrequest;
            c_status = local_c_status;
	}
	for (i=0; i<(int)*count; i++) {
	    lrequest[i] = MPI_Request_f2c( array_of_requests[i] );
	}

	*__ierr = MPI_Testall((int)*count,lrequest,&lflag,c_status);
        /* By checking for lrequest[i] = 0, we handle persistant requests */
	for (i=0; i<(int)*count; i++) {
	        array_of_requests[i] = MPI_Request_c2f( lrequest[i] );
	}
    }
    else
	*__ierr = MPI_Testall((int)*count,(MPI_Request *)0,&lflag,c_status);
    
    *flag = MPIR_TO_FLOG(lflag);
    /* We must only copy for those elements that corresponded to non-null
       requests, and only if there is a change */
    if (lflag && status_size_ok) {
	for (i=0; i<(int)*count; i++) {
	    MPI_Status_c2f( &c_status[i], &(array_of_statuses[i][0]) );
	}
    }

    if ((int)*count > FPMPI_LOCAL_ARRAY_SIZE) {
	free( lrequest );
	free( c_status );
    }
}

void STDCALL mpi_testany_( MPI_Fint *count, MPI_Fint array_of_requests[], 
		   MPI_Fint *index, MPI_Fint *flag, MPI_Fint *status, 
		   MPI_Fint *__ierr )
{
    int lindex;
    int lflag;
    MPI_Request *lrequest;
    MPI_Request local_lrequest[FPMPI_LOCAL_ARRAY_SIZE];
    MPI_Status c_status;
    int i;

    if ((int)*count > 0) {
	if ((int)*count > FPMPI_LOCAL_ARRAY_SIZE) {
	    lrequest = (MPI_Request*)malloc(sizeof(MPI_Request)* (int)*count);
	    if (!lrequest) { *__ierr = MPI_ERR_NOMEM; return; }
	}
	else 
	    lrequest = local_lrequest;
	
	for (i=0; i<(int)*count; i++) 
	    lrequest[i] = MPI_Request_f2c( array_of_requests[i] );
	
    }
    else
	lrequest = 0;

    *__ierr = MPI_Testany((int)*count,lrequest,&lindex,&lflag,&c_status);
    if (lindex != -1) {
        if (lflag && !*__ierr) {
	    array_of_requests[lindex] = MPI_Request_c2f(lrequest[lindex]);
        }
     }
    if ((int)*count > FPMPI_LOCAL_ARRAY_SIZE) 
	free( lrequest );
    
    *flag = MPIR_TO_FLOG(lflag);
    /* See the description of waitany in the standard; the Fortran index ranges
       are from 1, not zero */
    *index = (MPI_Fint)lindex;
    if ((int)*index >= 0) *index = *index + 1;
#ifdef HAVE_MPI_F_STATUS_IGNORE
    if (status != MPI_F_STATUS_IGNORE)
#endif
       MPI_Status_c2f(&c_status, status);
}

void STDCALL mpi_testsome_( MPI_Fint *incount, MPI_Fint array_of_requests[], 
		    MPI_Fint *outcount, MPI_Fint array_of_indices[], 
		    MPI_Fint array_of_statuses[][MPI_STATUS_SIZE], 
		    MPI_Fint *__ierr )
{
    int i,j,found;
    int loutcount;
    int *l_indices = 0;
    int local_l_indices[FPMPI_LOCAL_ARRAY_SIZE];
    MPI_Request *lrequest = 0;
    MPI_Request local_lrequest[FPMPI_LOCAL_ARRAY_SIZE];
    MPI_Status *c_status = 0;
    MPI_Status local_c_status[FPMPI_LOCAL_ARRAY_SIZE];

    if (status_size_ok == -1) {
	if (MPI_STATUS_SIZE != sizeof(MPI_Status)/sizeof(int)) {
	    /* Warning - */
	    fprintf( stderr, "Warning: The Fortran fpmpi code expected the sizeof MPI_Status\n\
 to be %d integers but it is %d.  Rebuild fpmpi and make sure that the\n\
 correct value is found and set in the fpmpiconf.h file\n", MPI_STATUS_SIZE,
		     (int) (sizeof(MPI_Status)/sizeof(int)) );
	    status_size_ok = 0;
	}
	else 
	    status_size_ok = 1;
    }
    if ((int)*incount > 0) {
        if ((int)*incount > FPMPI_LOCAL_ARRAY_SIZE) {
            lrequest = (MPI_Request*)malloc(sizeof(MPI_Request)* (int)*incount);
	    if (!lrequest) { *__ierr = MPI_ERR_NOMEM; return; }

	    l_indices = (int*)malloc(sizeof(int)* (int)*incount);
	    if (!l_indices) { *__ierr = MPI_ERR_NOMEM; return; }
	    c_status = (MPI_Status*)malloc(sizeof(MPI_Status)* (int)*incount);
	    if (!c_status) { *__ierr = MPI_ERR_NOMEM; return; }
	}
        else {
	    lrequest = local_lrequest;
	    l_indices = local_l_indices;
	    c_status = local_c_status;
	}

	for (i=0; i<(int)*incount; i++) {
	    lrequest[i] = MPI_Request_f2c( array_of_requests[i] );
	}
	*__ierr = MPI_Testsome((int)*incount,lrequest,&loutcount,l_indices,
			       c_status);

	/* By checking for lrequest[l_indices[i] =  0, 
           we handle persistant requests */
	for (i=0; i<(int)*incount; i++) {
	    if ( i < loutcount ) {
		    array_of_requests[l_indices[i]] =
			MPI_Request_c2f(lrequest[l_indices[i]] );
	    }
	    else {
		found = 0;
		j = 0;
		while ( (!found) && (j<loutcount) ) {
		    if (l_indices[j++] == i)
			found = 1;
		}
		if (!found)
		    array_of_requests[i] = MPI_Request_c2f( lrequest[i] );
	    }
	}
    }
    else
	*__ierr = MPI_Testsome( (int)*incount, (MPI_Request *)0, &loutcount, 
				l_indices, c_status );

    for (i=0; i<loutcount; i++) {
	if (status_size_ok) {
	    MPI_Status_c2f(&c_status[i], &(array_of_statuses[i][0]) );
	}
	if (l_indices[i] >= 0)
	    array_of_indices[i] = l_indices[i] + 1;
    }
    *outcount = (MPI_Fint)loutcount;
    if ((int)*incount > FPMPI_LOCAL_ARRAY_SIZE) {
        free( l_indices );
        free( lrequest );
        free( c_status );
    }

}


void STDCALL mpi_unpack_ ( void *inbuf, MPI_Fint *insize, MPI_Fint *position, 
		   void *outbuf, MPI_Fint *outcount, MPI_Fint *type, 
		   MPI_Fint *comm, MPI_Fint *__ierr )
{
    *__ierr = MPI_Unpack(inbuf, *insize, position, outbuf, *outcount, 
			 MPI_Type_f2c(*type), MPI_Comm_f2c(*comm) );
}

void STDCALL mpi_wait_ ( MPI_Fint *request, MPI_Fint *status, MPI_Fint *__ierr )
{
    MPI_Request lrequest;
    MPI_Status c_status;

    lrequest = MPI_Request_f2c(*request);
    *__ierr = MPI_Wait(&lrequest, &c_status);
    *request = MPI_Request_c2f(lrequest);

#ifdef HAVE_MPI_F_STATUS_IGNORE
    if (status != MPI_F_STATUS_IGNORE)
#endif
    MPI_Status_c2f(&c_status, status);
}

void STDCALL mpi_waitall_(MPI_Fint *count, MPI_Fint array_of_requests[], 
		  MPI_Fint array_of_statuses[][MPI_STATUS_SIZE], 
		  MPI_Fint *__ierr )
{
    int i;
    MPI_Request *lrequest = 0;
    MPI_Request local_lrequest[FPMPI_LOCAL_ARRAY_SIZE];
    MPI_Status *c_status = 0;
    MPI_Status local_c_status[FPMPI_LOCAL_ARRAY_SIZE];

    if (status_size_ok == -1) {
	if (MPI_STATUS_SIZE != sizeof(MPI_Status)/sizeof(int)) {
	    /* Warning - */
	    fprintf( stderr, "Warning: The Fortran fpmpi code expected the sizeof MPI_Status\n\
 to be %d integers but it is %d.  Rebuild fpmpi and make sure that the\n\
 correct value is found and set in the fpmpiconf.h file\n", MPI_STATUS_SIZE,
		     (int)(sizeof(MPI_Status)/sizeof(int)) );
	    status_size_ok = 0;
	}
	else 
	    status_size_ok = 1;
    }
    if ((int)*count > 0) {
	if ((int)*count > FPMPI_LOCAL_ARRAY_SIZE) {
	    lrequest = (MPI_Request*)malloc(sizeof(MPI_Request) * 
                        (int)*count);
	    if (!lrequest) { *__ierr = MPI_ERR_NOMEM; return; }
	    c_status = (MPI_Status*)malloc(sizeof(MPI_Status) * 
                        (int)*count);
	    if (!c_status) { *__ierr = MPI_ERR_NOMEM; return; }
	}
	else {
	    lrequest = local_lrequest;
	    c_status = local_c_status;
	}

	for (i=0; i<(int)*count; i++) {
	    lrequest[i] = MPI_Request_f2c( array_of_requests[i] );
	}

	*__ierr = MPI_Waitall((int)*count,lrequest,c_status);
	/* By checking for lrequest[i] = 0, we handle persistant requests */
	for (i=0; i<(int)*count; i++) {
	        array_of_requests[i] = MPI_Request_c2f( lrequest[i] );
	}
    }
    else 
	*__ierr = MPI_Waitall((int)*count,(MPI_Request *)0, c_status );

    if (status_size_ok) {
	for (i=0; i<(int)*count; i++) 
	    MPI_Status_c2f(&(c_status[i]), &(array_of_statuses[i][0]) );
    }
    
    if ((int)*count > FPMPI_LOCAL_ARRAY_SIZE) {
        free( lrequest );
        free( c_status );
    }
}

void STDCALL mpi_waitany_(MPI_Fint *count, MPI_Fint array_of_requests[], 
		  MPI_Fint *index, MPI_Fint *status, MPI_Fint *__ierr )
{

    int lindex;
    MPI_Request *lrequest = 0;
    MPI_Request local_lrequest[FPMPI_LOCAL_ARRAY_SIZE];
    MPI_Status c_status;
    int i;

    if ((int)*count > 0) {
	if ((int)*count > FPMPI_LOCAL_ARRAY_SIZE) {
	    lrequest = (MPI_Request*)malloc(sizeof(MPI_Request) * (int)*count);
	    if (!lrequest) { *__ierr = MPI_ERR_NOMEM; return; }
	}
	else 
	    lrequest = local_lrequest;
	
	for (i=0; i<(int)*count; i++) 
	    lrequest[i] = MPI_Request_f2c( array_of_requests[i] );
    }
    else
	lrequest = 0;

    *__ierr = MPI_Waitany((int)*count,lrequest,&lindex,&c_status);

    if (lindex != -1) {
	if (!*__ierr) {
                array_of_requests[lindex] = MPI_Request_c2f(lrequest[lindex]);
	}
    }

   if ((int)*count > FPMPI_LOCAL_ARRAY_SIZE) {
	free( lrequest );
    }

    /* See the description of waitany in the standard; the Fortran index ranges
       are from 1, not zero */
    *index = (MPI_Fint)lindex;
    if ((int)*index >= 0) *index = (MPI_Fint)*index + 1;
#ifdef HAVE_MPI_F_STATUS_IGNORE
    if (status != MPI_F_STATUS_IGNORE)
#endif
    MPI_Status_c2f(&c_status, status);
}

void STDCALL mpi_waitsome_( MPI_Fint *incount, MPI_Fint array_of_requests[], 
		    MPI_Fint *outcount, MPI_Fint array_of_indices[], 
		    MPI_Fint array_of_statuses[][MPI_STATUS_SIZE], 
		    MPI_Fint *__ierr )
{
    int i,j,found;
    int loutcount;
    int *l_indices = 0;
    int local_l_indices[FPMPI_LOCAL_ARRAY_SIZE];
    MPI_Request *lrequest = 0;
    MPI_Request local_lrequest[FPMPI_LOCAL_ARRAY_SIZE];
    MPI_Status * c_status = 0;
    MPI_Status local_c_status[FPMPI_LOCAL_ARRAY_SIZE];

    if (status_size_ok == -1) {
	if (MPI_STATUS_SIZE != sizeof(MPI_Status)/sizeof(int)) {
	    /* Warning - */
	    fprintf( stderr, "Warning: The Fortran fpmpi code expected the sizeof MPI_Status\n\
 to be %d integers but it is %d.  Rebuild fpmpi and make sure that the\n\
 correct value is found and set in the fpmpiconf.h file\n", MPI_STATUS_SIZE,
		     (int)(sizeof(MPI_Status)/sizeof(int)) );
	    status_size_ok = 0;
	}
	else 
	    status_size_ok = 1;
    }
    if ((int)*incount > 0) {
	if ((int)*incount > FPMPI_LOCAL_ARRAY_SIZE) {
	    lrequest = (MPI_Request*)malloc(sizeof(MPI_Request)* (int)*incount);
	    if (!lrequest) { *__ierr = MPI_ERR_NOMEM; return; }
	    l_indices = (int*)malloc(sizeof(int)* (int)*incount);
	    if (!l_indices) { *__ierr = MPI_ERR_NOMEM; return; }
	    c_status = (MPI_Status*)malloc(sizeof(MPI_Status)* (int)*incount);
	    if (!c_status) { *__ierr = MPI_ERR_NOMEM; return; }
	}
	else {
	    lrequest = local_lrequest;
	    l_indices = local_l_indices;
	    c_status = local_c_status;
	}

	for (i=0; i<(int)*incount; i++) 
	    lrequest[i] = MPI_Request_f2c( array_of_requests[i] );
	
	*__ierr = MPI_Waitsome((int)*incount,lrequest,&loutcount,l_indices,
			       c_status);

/* By checking for lrequest[l_indices[i]] = 0, we handle persistant requests */
        for (i=0; i<(int)*incount; i++) {
	    if ( i < loutcount) {
                if (l_indices[i] >= 0) {
		        array_of_requests[l_indices[i]] = 
			      MPI_Request_c2f( lrequest[l_indices[i]] );
		}
	    }
	    else {
		found = 0;
		j = 0;
		while ( (!found) && (j<loutcount) ) {
		    if (l_indices[j++] == i)
			found = 1;
		}
		if (!found)
	            array_of_requests[i] = MPI_Request_c2f( lrequest[i] );
	    }
	}
    }
    else 
	*__ierr = MPI_Waitsome( (int)*incount, (MPI_Request *)0, &loutcount,
			       l_indices, c_status );

    for (i=0; i<loutcount; i++) {
	if (status_size_ok) {
	    MPI_Status_c2f( &c_status[i], &(array_of_statuses[i][0]) );
	}
	if (l_indices[i] >= 0)
	    array_of_indices[i] = l_indices[i] + 1;

    }
    *outcount = (MPI_Fint)loutcount;
    if ((int)*incount > FPMPI_LOCAL_ARRAY_SIZE) {
        free( l_indices );
        free( lrequest );
        free( c_status );
    }
}

void STDCALL mpi_allgather_ ( void *sendbuf, MPI_Fint *sendcount, MPI_Fint *sendtype, 
		      void *recvbuf, MPI_Fint *recvcount, MPI_Fint *recvtype,
		      MPI_Fint *comm, MPI_Fint *__ierr )
{
    *__ierr = MPI_Allgather(sendbuf, *sendcount, MPI_Type_f2c(*sendtype),
			    recvbuf, *recvcount, MPI_Type_f2c(*recvtype), 
			    MPI_Comm_f2c(*comm) );
}


void STDCALL mpi_allgatherv_ ( void *sendbuf, MPI_Fint *sendcount, MPI_Fint *sendtype,
		       void *recvbuf, MPI_Fint *recvcounts, MPI_Fint *displs,
		       MPI_Fint *recvtype, MPI_Fint *comm, MPI_Fint *__ierr )
{
    *__ierr = MPI_Allgatherv(sendbuf, *sendcount, MPI_Type_f2c(*sendtype),
			     recvbuf, recvcounts, displs, 
			     MPI_Type_f2c(*recvtype), MPI_Comm_f2c(*comm) );
}


void STDCALL mpi_allreduce_ ( void *sendbuf, void *recvbuf, MPI_Fint *count, 
		      MPI_Fint *datatype, MPI_Fint *op, MPI_Fint *comm,
		      MPI_Fint *__ierr )
{
    *__ierr = MPI_Allreduce(sendbuf, recvbuf, *count, MPI_Type_f2c(*datatype),
			    MPI_Op_f2c(*op), MPI_Comm_f2c(*comm) );
}


void STDCALL mpi_alltoall_( void *sendbuf, MPI_Fint *sendcount, MPI_Fint *sendtype,
		    void *recvbuf, MPI_Fint *recvcnt, MPI_Fint *recvtype, 
		    MPI_Fint *comm, MPI_Fint *__ierr )
{
    *__ierr = MPI_Alltoall(sendbuf, *sendcount, MPI_Type_f2c(*sendtype),
			   recvbuf, *recvcnt, MPI_Type_f2c(*recvtype), 
			   MPI_Comm_f2c(*comm) );
}


void STDCALL mpi_alltoallv_ ( void *sendbuf, MPI_Fint *sendcnts, MPI_Fint *sdispls, 
		      MPI_Fint *sendtype, void *recvbuf, MPI_Fint *recvcnts,
		      MPI_Fint *rdispls, MPI_Fint *recvtype, MPI_Fint *comm, 
		      MPI_Fint *__ierr )
{
    *__ierr = MPI_Alltoallv(sendbuf, sendcnts, sdispls, 
			    MPI_Type_f2c(*sendtype), recvbuf,
			    recvcnts, rdispls, MPI_Type_f2c(*recvtype),
			    MPI_Comm_f2c(*comm) );
}

void STDCALL mpi_barrier_ ( MPI_Fint *comm, MPI_Fint *__ierr )
{
    *__ierr = MPI_Barrier( MPI_Comm_f2c(*comm) );
}

void STDCALL mpi_iprobe_ ( MPI_Fint *source, MPI_Fint *tag, MPI_Fint *comm,
                   MPI_Fint *flag, MPI_Fint *status, MPI_Fint *__ierr )
{
    int        l_flag;
    MPI_Status c_status;
    *__ierr = MPI_Iprobe((int)*source,(int)*tag, MPI_Comm_f2c(*comm),
                         &l_flag, &c_status );
    *flag = MPIR_TO_FLOG(l_flag);
    if (l_flag) {
#ifdef HAVE_MPI_F_STATUS_IGNORE
       if (status != MPI_F_STATUS_IGNORE)
#endif
      MPI_Status_c2f(&c_status,status);
    }
}

void STDCALL mpi_probe_ ( MPI_Fint *source, MPI_Fint *tag, MPI_Fint *comm,
                  MPI_Fint *status, MPI_Fint *__ierr )
{
    MPI_Status c_status;
    *__ierr = MPI_Probe((int)*source,(int)*tag, MPI_Comm_f2c(*comm),
                        &c_status );
#ifdef HAVE_MPI_F_STATUS_IGNORE
    if (status != MPI_F_STATUS_IGNORE)
#endif
    MPI_Status_c2f(&c_status,status);
}

void STDCALL mpi_bcast_ ( void *buffer, MPI_Fint *count, MPI_Fint *datatype, 
		  MPI_Fint *root, MPI_Fint *comm, MPI_Fint *__ierr )
{
    *__ierr = MPI_Bcast(buffer, *count, MPI_Type_f2c(*datatype), *root, 
			MPI_Comm_f2c(*comm) );
}

void STDCALL mpi_comm_dup_ ( MPI_Fint *oldcomm, MPI_Fint *newcomm, MPI_Fint *__ierr )
{
    MPI_Comm l_comm;
    *__ierr = MPI_Comm_dup(MPI_Comm_f2c(*oldcomm), &l_comm);
    *newcomm = MPI_Comm_c2f(l_comm);
}

void STDCALL mpi_comm_split_ ( MPI_Fint *oldcomm, MPI_Fint *color, MPI_Fint *key,
                       MPI_Fint *newcomm, MPI_Fint *__ierr )
{
    MPI_Comm l_comm;
    *__ierr = MPI_Comm_split(MPI_Comm_f2c(*oldcomm), (int)*color, (int)*key,
                             &l_comm);
    *newcomm = MPI_Comm_c2f(l_comm);
}

void STDCALL mpi_comm_free_ ( MPI_Fint *comm, MPI_Fint *__ierr )
{
    MPI_Comm l_comm = MPI_Comm_f2c(*comm);
    *__ierr         = MPI_Comm_free(&l_comm);
    *comm           = MPI_Comm_c2f(l_comm);
}

void STDCALL mpi_gather_ ( void *sendbuf, MPI_Fint *sendcnt, MPI_Fint *sendtype,
		   void *recvbuf, MPI_Fint *recvcount, MPI_Fint *recvtype, 
		   MPI_Fint *root, MPI_Fint *comm, MPI_Fint *__ierr )
{
    *__ierr = MPI_Gather(sendbuf, *sendcnt, MPI_Type_f2c(*sendtype),
			 recvbuf, *recvcount, MPI_Type_f2c(*recvtype), *root,
			 MPI_Comm_f2c(*comm) );
}


void STDCALL mpi_gatherv_ ( void *sendbuf, MPI_Fint *sendcnt, MPI_Fint *sendtype, 
		    void *recvbuf, MPI_Fint *recvcnts, MPI_Fint *displs, 
		    MPI_Fint *recvtype, MPI_Fint *root, MPI_Fint *comm, 
		    MPI_Fint *__ierr )
{
    *__ierr = MPI_Gatherv(sendbuf, *sendcnt, MPI_Type_f2c(*sendtype), 
			  recvbuf, recvcnts, displs, 
			  MPI_Type_f2c(*recvtype), *root, 
			  MPI_Comm_f2c(*comm) );
}


void STDCALL mpi_reduce_scatter_ ( void *sendbuf, void *recvbuf, MPI_Fint *recvcnts,
			   MPI_Fint *datatype, MPI_Fint *op, MPI_Fint *comm, 
			   MPI_Fint *__ierr )
{
    *__ierr = MPI_Reduce_scatter(sendbuf, recvbuf, recvcnts, 
				 MPI_Type_f2c(*datatype), MPI_Op_f2c(*op),
                                 MPI_Comm_f2c(*comm) );
}

void STDCALL mpi_reduce_ ( void *sendbuf, void *recvbuf, MPI_Fint *count, 
		   MPI_Fint *datatype, MPI_Fint *op, MPI_Fint *root, 
		   MPI_Fint *comm, MPI_Fint *__ierr )
{
    *__ierr = MPI_Reduce(sendbuf, recvbuf, *count, MPI_Type_f2c(*datatype),
			 MPI_Op_f2c(*op), *root, MPI_Comm_f2c(*comm) );
}

void STDCALL mpi_scan_ ( void *sendbuf, void *recvbuf, MPI_Fint *count, 
		 MPI_Fint *datatype, MPI_Fint *op, MPI_Fint *comm, 
		 MPI_Fint *__ierr )
{
    *__ierr = MPI_Scan(sendbuf, recvbuf, *count, MPI_Type_f2c(*datatype),
		       MPI_Op_f2c(*op), MPI_Comm_f2c(*comm) );
}

void STDCALL mpi_scatter_ ( void *sendbuf, MPI_Fint *sendcnt, MPI_Fint *sendtype, 
		    void *recvbuf, MPI_Fint *recvcnt, MPI_Fint *recvtype, 
                    MPI_Fint *root, MPI_Fint *comm, MPI_Fint *__ierr )
{
    *__ierr = MPI_Scatter(sendbuf, *sendcnt, MPI_Type_f2c(*sendtype), 
			  recvbuf, *recvcnt, MPI_Type_f2c(*recvtype),
			  *root, MPI_Comm_f2c(*comm));
}

void STDCALL mpi_scatterv_ ( void *sendbuf, MPI_Fint *sendcnts, MPI_Fint *displs, 
		     MPI_Fint *sendtype, void *recvbuf, MPI_Fint *recvcnt,
		     MPI_Fint *recvtype, MPI_Fint *root, MPI_Fint *comm, 
		     MPI_Fint *__ierr )
{
    *__ierr = MPI_Scatterv(sendbuf, sendcnts, displs, MPI_Type_f2c(*sendtype),
			   recvbuf, *recvcnt, MPI_Type_f2c(*recvtype), *root,
			   MPI_Comm_f2c(*comm) );
}

void STDCALL mpi_finalize_( MPI_Fint *ierr )
{
    *ierr = MPI_Finalize();
}

